import { eventBus } from "../events/eventBus";
import { createDemoJob, updateJobStatus, listJobs } from "../models/jobStore";
import { addMemoryForUser, listMemoriesForUser } from "../models/memoryStore";

export interface ChatMessage {
  id: string;
  conversationId: string;
  role: "user" | "assistant" | "tool" | "system";
  content: string;
  createdAt: string;
}

let messageCounter = 0;

/**
 * Very small persona stub.
 * Later this will call your real LLM, memory, tools, workers, etc.
 *
 * For now it:
 * - echoes the user message back
 * - creates a demo background job
 * - adds a simple memory summary
 * - emits corresponding events for the UI
 */
export async function handleUserMessage(
  conversationId: string,
  userId: string,
  text: string
): Promise<ChatMessage> {
  messageCounter += 1;

  // Create assistant reply
  const reply: ChatMessage = {
    id: `msg-${messageCounter}`,
    conversationId,
    role: "assistant",
    content: `You said: "${text}". This is a stub response from your future persona.`,
    createdAt: new Date().toISOString()
  };

  // Create a demo background job to showcase job panel + events
  const jobLabel = `Process message: "${text.slice(0, 32)}${text.length > 32 ? "…" : ""}"`;
  const job = createDemoJob(jobLabel, "tool");

  // Emit initial job state
  await eventBus.emit({
    type: "job_updated",
    payload: { jobs: listJobs() }
  });

  // Simulate job progress over time
  setTimeout(async () => {
    updateJobStatus(job.id, "running");
    await eventBus.emit({
      type: "job_updated",
      payload: { jobs: listJobs() }
    });
  }, 500);

  setTimeout(async () => {
    updateJobStatus(job.id, "done");
    await eventBus.emit({
      type: "job_updated",
      payload: { jobs: listJobs() }
    });
  }, 1500);

  // Add a tiny memory item for the user
  addMemoryForUser(
    userId,
    "Recent message summary",
    `User said: "${text.slice(0, 80)}${text.length > 80 ? "…" : ""}".`
  );

  await eventBus.emit({
    type: "memory_updated",
    payload: { userId, memories: listMemoriesForUser(userId) }
  });

  return reply;
}
