export type MemoryKind = "fact" | "preference" | "summary";

export interface MemoryItem {
  id: string;
  userId: string;
  kind: MemoryKind;
  title: string;
  content: string;
  createdAt: string;
}

const memories: MemoryItem[] = [];

export function addMemoryForUser(
  userId: string,
  title: string,
  content: string,
  kind: MemoryKind = "summary"
): MemoryItem {
  const item: MemoryItem = {
    id: `mem-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    userId,
    kind,
    title,
    content,
    createdAt: new Date().toISOString()
  };
  memories.push(item);
  return item;
}

export function listMemoriesForUser(userId: string): MemoryItem[] {
  return memories
    .filter((m) => m.userId === userId)
    .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}
