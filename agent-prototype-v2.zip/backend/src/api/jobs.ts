import type { FastifyInstance } from "fastify";
import { listJobs } from "../models/jobStore";

export async function registerJobsRoutes(app: FastifyInstance) {
  app.get("/api/jobs", async (_req, reply) => {
    const jobs = listJobs();
    return reply.send({ jobs });
  });
}
