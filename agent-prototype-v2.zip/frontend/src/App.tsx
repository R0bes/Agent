import React from "react";
import { ChatView } from "./components/ChatView";
import { JobsPanel } from "./components/JobsPanel";
import { MemoryPanel } from "./components/MemoryPanel";

export const App: React.FC = () => {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="persona-avatar" />
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="persona-name">Your Agent</div>
          <div id="persona-status" className="persona-status">
            Ready
          </div>
        </header>

        <section className="chat-section">
          <ChatView />
        </section>
      </main>

      <aside className="right-panel">
        <JobsPanel />
        <MemoryPanel />
      </aside>
    </div>
  );
};
